$item modify entity @s armor.head {"function":"set_components","components":{"minecraft:dyed_color":$(color)}}
$item modify entity @s armor.legs {"function":"set_components","components":{"minecraft:dyed_color":$(color)}}
$item modify entity @s armor.feet {"function":"set_components","components":{"minecraft:dyed_color":$(color)}}